package print;

public class PrintTest01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//출력메소드 : ()소괄호 안에 있는 값을 콘솔창에 출력한다
		//println() : 소괄호 안에 있는 값을 콘솔창에 출력하고 줄바꿈이 된다
		//print() : 소괄호 안에 있는 값을 콘솔창에 출력하고 줄바꿈이 되지 않는다
		System.out.print("김영선");
		//이동 alt + 방향키 위아래
		System.out.println(10 + 20);
		//실행 ctrl + F11
		//출력메소드 syso + ctrl + space bar + 엔터
		System.out.println("10 + 20");
		System.out.println(10 + 2.5); //정수 + 실수 = 실수
		//복사 ctrl + alt + 방향키 위아래
	}

}
