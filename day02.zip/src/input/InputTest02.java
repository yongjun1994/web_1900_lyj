package input;

import java.util.Scanner;

public class InputTest02 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		//입력받은 값을 문자열로 돌려준다
		//next()와 nextLine()의 차이는 임시 저장공간에서 엔터를 소모하냐 소모하지 않느냐에 있다
		//nextLine()만 임시 저장공간에서 엔터를 지워준다(소모한다)
//		sc.next();
//		sc.next();
//		sc.next();
//		sc.nextLine();
//		sc.nextLine();
//		sc.nextLine();
	
	}
}
